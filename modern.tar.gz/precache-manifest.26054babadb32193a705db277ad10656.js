self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "76b9c9f0bd07d134041c",
    "url": "css/app.893c7cfa.css"
  },
  {
    "revision": "45bf2690f95a4ac863dc",
    "url": "css/chunk-vendors.8cf7dd44.css"
  },
  {
    "revision": "bf261ab0e8644ee5cde1ee6e62f5da95",
    "url": "d422312fb4aaee70d8a3.worker.js"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "de1b4822431b003df552ff6d889664e1",
    "url": "index.html"
  },
  {
    "revision": "76b9c9f0bd07d134041c",
    "url": "js/app.3e4b09a9.js"
  },
  {
    "revision": "45bf2690f95a4ac863dc",
    "url": "js/chunk-vendors.7d5ad845.js"
  },
  {
    "revision": "28f3e13ec88073aa1b85b7d66358f613",
    "url": "manifest.json"
  },
  {
    "revision": "523b1a2eae8cb533fa6bd73831308f09",
    "url": "static/kgm.mask"
  }
]);