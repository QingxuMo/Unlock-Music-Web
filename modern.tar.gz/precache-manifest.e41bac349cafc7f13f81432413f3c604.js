self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "16154accc526c64d23938577f9487b09",
    "url": "85498e2d6100df0f705c.worker.js"
  },
  {
    "revision": "5ed90db6cf4c8f6141ae",
    "url": "css/app.893c7cfa.css"
  },
  {
    "revision": "96300d510523d3d08574",
    "url": "css/chunk-vendors.8cf7dd44.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "86f2c94ecf0e1b943822502cd4f40874",
    "url": "index.html"
  },
  {
    "revision": "5ed90db6cf4c8f6141ae",
    "url": "js/app-legacy.6e89945e.js"
  },
  {
    "revision": "96300d510523d3d08574",
    "url": "js/chunk-vendors-legacy.98df5217.js"
  },
  {
    "revision": "28f3e13ec88073aa1b85b7d66358f613",
    "url": "manifest.json"
  }
]);